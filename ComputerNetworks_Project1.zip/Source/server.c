
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <stdlib.h>

#define MAX 100

int main(int argc, char *argv[])
{
	struct addrinfo hints, *res;
	int status;
	char inbuff[MAX], outbuff[MAX];
	char client_ip[NI_MAXHOST];

	// Initialize hints structure
	memset(&hints, 0, sizeof hints);
	hints.ai_family = AF_INET;		 // IPv4
	hints.ai_socktype = SOCK_STREAM; // TCP
	hints.ai_flags = AI_PASSIVE;	 // Use my IP address

	// check for correct command line arguments
	if (argc != 2)
	{
		printf("usage: %s <port>\nExample: %s 3000\n", argv[0], argv[0]);
		return (1);
	}

	// get address information for the server
	if ((status = getaddrinfo(NULL, argv[1], &hints, &res)) != 0)
	{
		fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(status));
		return 2;
	}

	int sockfd = socket(res->ai_family, res->ai_socktype, res->ai_protocol);

	// Attempt to bind to the port to check if it's in use
	int test_bind = bind(sockfd, res->ai_addr, res->ai_addrlen);
	if (test_bind == -1)
	{
		perror("bind");
		return 2;
	}
	
	//listen for incoming connections
	listen(sockfd, 10); // up to 10 connection requests can be queued (backlog = 10)
	while (1)
	{

		struct sockaddr_storage *theiraddr;
		socklen_t addr_size = sizeof theiraddr;
		int new_fd = accept(sockfd, (struct sockaddr *)&theiraddr, &addr_size);

		// get client's IP address
		getnameinfo((struct sockaddr *)&theiraddr, addr_size, client_ip, sizeof client_ip, NULL, 0, NI_NUMERICHOST);


		printf("A new client connected to the server:");
		int shouldExit = 0; // flag to control loop exit

		while (!shouldExit)
		{
			memset(inbuff, 0, MAX);
			memset(outbuff, 0, MAX);
			printf("\n%s $ ", client_ip);
			// get command from server
			fgets(outbuff, MAX, stdin);

			// remove newline character
			outbuff[strcspn(outbuff, "\n")] = 0;

			// send command to client
			send(new_fd, outbuff, strlen(outbuff), 0);

			// close connection if command is END
			if (strcmp(outbuff, "END") == 0)
			{
				close(new_fd);
				break;
			}

			// receive and print output from client
			while (1)
			{
				ssize_t bytesRecieved = recv(new_fd, inbuff, MAX, 0);
				if (bytesRecieved <= 0)
				{
					printf("client disconnected.\n");
					close(new_fd);
					shouldExit = 1; // set flag to exit both inner loops
					break;
				}
				if (strstr(inbuff, "***") != NULL)
				{ // exit the inner loop when "***" is recieved
					printf("%.*s", (int)(bytesRecieved - 3), inbuff);
					break;
				}
				printf("%.*s", (int)bytesRecieved, inbuff);
			}
		}
	}
	return 0;
}
