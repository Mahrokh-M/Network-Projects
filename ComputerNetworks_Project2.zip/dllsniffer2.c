#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netpacket/packet.h>
#include <net/ethernet.h> // For data link layer (DLL) protocols
#include <arpa/inet.h>   // For htons function
#include <unistd.h>

// Function to determine packet type
const char* get_packet_type(unsigned short pkttype) {
    switch (pkttype) {
        case PACKET_HOST:
            return "Incoming";
        case PACKET_BROADCAST:
            return "Broadcast";
        case PACKET_MULTICAST:
            return "Multicast";
        case PACKET_OUTGOING:
            return "Outgoing";
        default:
            return "Unknown";
    }
}

// Function to determine higher layer protocol type
const char* get_higher_layer_protocol(unsigned short ethertype) {
    switch (ethertype) {
        case ETH_P_IP:
            return "IP";
        case ETH_P_ARP:
            return "ARP";
        default:
            return "Unknown";
    }
}

int main() {
    int sockfd;
    char buffer[2048];
    struct sockaddr_ll phyaddr;
    socklen_t len = sizeof(struct sockaddr_ll);

    // Create a raw socket
    sockfd = socket(PF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
    if (sockfd == -1) {
        perror("Error creating raw socket");
        exit(EXIT_FAILURE);
    }

    while (1) {
        ssize_t bytes_received = recvfrom(sockfd, buffer, sizeof(buffer), 0, (struct sockaddr *)&phyaddr, &len);
        if (bytes_received == -1) {
            perror("Error receiving packet");
            continue;
        }

        const char* packet_type = get_packet_type(phyaddr.sll_pkttype);

        // Extract the EtherType field from the Ethernet header
        unsigned short ethertype = ntohs(((struct ethhdr*)buffer)->h_proto);
        const char* higher_layer_protocol = get_higher_layer_protocol(ethertype);

        // Print the packet type, higher layer protocol type, and content in hexadecimal
        printf("Upper Protocol: %s, %s: ", higher_layer_protocol, packet_type);
        for (ssize_t i = 0; i < bytes_received; ++i) {
            printf("%02x", (unsigned char)buffer[i]);
        }
        printf("\n");
    }

    close(sockfd);
    return 0;
}

